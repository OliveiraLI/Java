
package Fibonacci1.servlets;


public class contador {
    
    public static int calculo (int n){
int b = 0;
int ant = 0;

for (int i=1; i <= n; i++){
	if (i == 1){
    b=1;
    ant =0;
}else{
    b += ant;
    ant = b - ant;
}

}
return b;
}
}
    

